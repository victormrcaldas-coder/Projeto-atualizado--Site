# MeMotiva — Curadoria

```
Frases:              3.196
Pessoas:             474
Panoramas curados:   355
Páginas de obra:     73   (eram 17 há duas rodadas)
Obras catalogadas:   932
Próximo autor:       Elisabeth Kübler-Ross
```

---

## 1. Revisão da quarentena — a resposta à sua pergunta

Reli as 995 frases removidas, uma a uma. A pergunta era se, agora que houve
pesquisa individual por autor, alguma delas tem obra identificável.

**Resposta: 42 tinham. As outras 953 não.**

O que dava para resgatar era o que eu conseguia localizar com precisão:

| Frase | Onde estava | Onde está agora |
|---|---|---|
| *Eu não pinto sonhos nem pesadelos* — Frida Kahlo | sem fonte | Declaração em resposta ao rótulo surrealista de Breton |
| *Tente ser um arco-íris na nuvem de alguém* — Maya Angelou | "Obra e entrevistas" | Carta à Minha Filha (2008) |
| *Para o crente, Deus está no princípio* — Max Planck | sem fonte | Religião e Ciência Natural (1937) |
| *A amizade é antes de tudo certeza* — Yourcenar | sem fonte | Memórias de Adriano, seção Varius Multiplex |
| *Há escolas que são gaiolas e escolas que são asas* — Rubem Alves | "Obra de Rubem Alves" | A Alegria de Ensinar (1994) |
| *A única liberdade que merece o nome* — Mill | "Obra de John Stuart Mill" | Sobre a Liberdade (1859), cap. 1 |
| *A leitura torna o homem completo* — Bacon | "Obra de Francis Bacon" | Ensaios (1625), Dos Estudos |

As 953 restantes ficam onde estão. São, na maioria esmagadora, frases que
circulam em agregadores sem que exista fonte primária — e a pesquisa individual
que fiz por autor não mudou isso. Continuam acessíveis por `QUARENTENA()`.

### Uma má-atribuição encontrada dentro da própria quarentena

*"A amizade é o conforto indescritível de nos sentirmos seguros com uma pessoa,
sem ter de pesar pensamentos nem medir palavras"* estava atribuída a
**George Eliot**. É de **Dinah Maria Craik**, romancista inglesa contemporânea
dela, em *A Life for a Life* (1859), capítulo 16. Devolvi a frase à autora
correta e criei o panorama dela, que agora entra no acervo.

## 2. Páginas de obra — de 50 para 73

Seguindo a fila de `OBRAS_SEM_PAGINA()`. Entraram Crime e Castigo, Os Irmãos
Karamázov, Guerra e Paz, Grande Sertão: Veredas, A Paixão Segundo G.H.,
Em Busca do Tempo Perdido, O Velho e o Mar, A Revolução dos Bichos, A Peste,
Adeus às Armas, Ficções, Quincas Borba, Emma, Um Conto de Natal,
Huckleberry Finn, Ensaio sobre a Cegueira, Sapiens, Rápido e Devagar,
Os 7 Hábitos, As 48 Leis do Poder, Pedagogia da Autonomia, Gitanjali,
Fundamentação da Metafísica dos Costumes, O Medo à Liberdade e
História da Filosofia Ocidental.

**Zero páginas órfãs.**

## 3. Panoramas

Cinco novos: Rubem Alves, Vince Lombardi, Booker T. Washington, Sojourner Truth
e Dinah Maria Craik. Total: **355 de 474**.

O de Sojourner Truth traz uma ressalva que quase nunca aparece: a versão mais
conhecida de seu discurso em Akron foi transcrita doze anos depois por Frances
Gage, que acrescentou um sotaque sulista que Truth — nascida em Nova York e
falante de holandês como primeira língua — não tinha.

## 4. Testes

```
frasesInvalidas ....... 0      obrasInvalidas ........ 0
categoriaInvalida ..... 0      obrasNaoConfirmadas ... 0
qidDuplicado .......... 0      oidDuplicado .......... 0
panoramaVazio ......... 0      paginaOrfa ............ 0
srcVazio .............. 0

render de panoramas ... 0 falhas   (355)
bibliotecas de obras .. 0 falhas   (474 autores)
cartões de frase ...... 0 falhas   (3.196)
procedências .......... 0 falhas
```

## 5. Pendente

| | |
|---|---|
| Autores com 1 ou 2 frases | 208 |
| Autores sem panorama | 119 |
| Obras sem página própria | 859 |
| Frases com conjunto de obras candidatas | 306 |

## Consultas

```js
CURADORIA_RELATORIO()   AUDITORIA()          OBRAS_SEM_PAGINA(40)
QUARENTENA()            RESIDUAL()           DIAGNOSTICO_LAYOUT()
ATRIBUICOES_VERIFICADAS()                    CURADORIA_PROXIMOS(20)
```
